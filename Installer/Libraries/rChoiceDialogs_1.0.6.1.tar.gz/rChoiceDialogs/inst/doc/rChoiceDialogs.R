### R code from vignette source 'rChoiceDialogs.Rnw'

###################################################
### code chunk number 1: sessionInfo
###################################################

library(rChoiceDialogs)

toLatex(sessionInfo())



